const listaCanciones = [
    { id: 0, titulo: "Daniel, me estás matando - Lo Hice, Te Dejé", src: "music/Daniel me estas matando - Lo Hice Te Deje.mp3" },
    { id: 1, titulo: "Frank Ocean - Thinkin Bout You", src: "music/Frank Ocean - Thinkin Bout You.mp3" },
    { id: 2, titulo: "Kali Uchis - Quiero Sentirme Bien", src: "music/Kali Uchis – quiero sentirme bien.mp3" },
    { id: 3, titulo: "Lana del Rey - Million Dollar Man", src: "music/Lana del Rey - Million Dollar Man.mp3" },
    { id: 4, titulo: "Shakira - Día De Enero", src: "music/Shakira - Dia De Enero.mp3" },
    { id: 5, titulo: "SZA - Love Galore (Alt Version)", src: "music/SZA - Love Galore (Alt Version).mp3" },
    { id: 6, titulo: "The Weeknd - In The Night", src: "music/The Weeknd - In The Night.mp3" }
];

let indiceActual = 0;
let estaEncendido = false; // CORRECCIÓN: El aparato arranca completamente APAGADO por defecto

const reproductorAudio = document.getElementById("reproductor-audio");
const carreteIzq = document.getElementById("carrete-izq");
const carreteDer = document.getElementById("carrete-der");
const ledEstadoPower = document.getElementById("led-estado-power"); 
const menuPlaylist = document.getElementById("playlist-menu");
const contenedorLista = document.getElementById("lista-canciones");

const btnPlayPause = document.getElementById("btn-play-pause");
const btnRewind = document.getElementById("btn-rewind");
const btnShuffle = document.getElementById("btn-shuffle");
const btnPlaylist = document.getElementById("btn-playlist");
const btnStop = document.getElementById("btn-stop"); 

function cargarPlaylistVisual() {
    contenedorLista.innerHTML = "";
    listaCanciones.forEach((cancion) => {
        const li = document.createElement("li");
        li.textContent = cancion.titulo;
        li.setAttribute("data-id", cancion.id);
        li.addEventListener("click", () => {
            if (estaEncendido) seleccionarCancion(cancion.id);
        });
        contenedorLista.appendChild(li);
    });
}

function seleccionarCancion(id) {
    indiceActual = id;
    reproductorAudio.src = listaCanciones[indiceActual].src;
    
    document.querySelectorAll("#lista-canciones li").forEach(li => {
        li.classList.remove("cancion-activa");
        if(parseInt(li.getAttribute("data-id")) === id) {
            li.classList.add("cancion-activa");
        }
    });

    reproducirMusica();
}

function reproducirMusica() {
    if (!estaEncendido) return; 

    reproductorAudio.play().then(() => {
        carreteIzq.classList.add("girando");
        carreteDer.classList.add("girando");
        
        btnPlayPause.querySelector(".fa-play").style.display = "none";
        btnPlayPause.querySelector(".fa-pause").style.display = "inline-block";
        btnPlayPause.classList.add("activo");
    }).catch(err => console.log("Verifica las rutas de tus archivos mp3"));
}

function pausarMusica() {
    reproductorAudio.pause();
    carreteIzq.classList.remove("girando");
    carreteDer.classList.remove("girando");
    
    btnPlayPause.querySelector(".fa-play").style.display = "inline-block";
    btnPlayPause.querySelector(".fa-pause").style.display = "none";
    btnPlayPause.classList.remove("activo");
}

// INTERRUPTOR GENERAL DE ENERGÍA (BOTÓN POWER)
btnStop.addEventListener("click", () => {
    estaEncendido = !estaEncendido;

    if (estaEncendido) {
        // Al encender -> Poner verde
        ledEstadoPower.classList.add("led-verde");
        console.log("Casetera Encendida - Luz Verde");
    } else {
        // Al apagar -> Volver a Rojo
        ledEstadoPower.classList.remove("led-verde");
        
        // Detener procesos de inmediato y asegurar que el panel se oculte
        pausarMusica();
        reproductorAudio.currentTime = 0;
        menuPlaylist.style.display = "none"; 
        console.log("Casetera Apagada - Luz Roja");
    }
});

// EVENTOS DE LOS CONTROLES MECÁNICOS
btnPlayPause.addEventListener("click", () => {
    if (!estaEncendido) return; 

    if (!reproductorAudio.src) {
        seleccionarCancion(0);
    } else if (reproductorAudio.paused) {
        reproducirMusica();
    } else {
        pausarMusica();
    }
});

btnRewind.addEventListener("click", () => {
    if (!estaEncendido) return;
    reproductorAudio.currentTime = 0;
});

btnShuffle.addEventListener("click", () => {
    if (!estaEncendido) return;
    let nuevoIndice;
    do {
        nuevoIndice = Math.floor(Math.random() * listaCanciones.length);
    } while (nuevoIndice === indiceActual && listaCanciones.length > 1);
    seleccionarCancion(nuevoIndice);
});

// Control del despliegue de la playlist usando los estilos computados de forma limpia
btnPlaylist.addEventListener("click", () => {
    if (!estaEncendido) return;
    
    if (menuPlaylist.style.display === "block") {
        menuPlaylist.style.display = "none";
    } else {
        menuPlaylist.style.display = "block";
    }
});

reproductorAudio.addEventListener("ended", () => {
    pausarMusica();
});

// Inicialización de la interfaz
cargarPlaylistVisual();